# MSB Quiz Helper — Chrome Extension (MV3)

Versi extension dari userscript Grey Ball (v2.3.1): **Groq utama** (gpt-oss-120b,
1.000 req/hari gratis) → fallback **Gemini** (rotasi key) → AI lokal Chrome.
Tombol **C** = toggle bola · right-click/tombol-samping mouse = bola diproteksi.

> ZIP ini TANPA API key (biar aman di-push ke GitHub).
> Key diisi lewat POPUP setelah install — sekali isi, berlaku di SEMUA situs.

## Cara Install

1. Download & extract zip ini
2. Buka `chrome://extensions` → aktifkan **Developer mode** (kanan atas)
3. Klik **Load unpacked** → pilih foldernya
4. Klik ikon extension → di bagian 🔑 API Keys:
   - **Groq key** (utama): ambil gratis di https://console.groq.com/keys
   - **Gemini keys** (fallback, opsional, 1 per baris): https://aistudio.google.com/apikey
5. Klik 💾 Simpan → buka halaman soal → bola abu-abu muncul kanan-bawah

## Tombol & shortcut

| Aksi | Cara |
|---|---|
| Jawab semua soal | Klik bola abu-abu / popup ▶ / `msb.run()` |
| Undo jawaban | Klik bola putih ↺ / popup / `msb.undo()` |
| Sembunyi↔muncul bola | Tekan **C** (di luar input) / popup / `msb.toggle()` |
| Lihat status key & kuota | `msb.status()` di console |
| Tambah key Gemini | popup (1 per baris) atau `msb.addGeminiKey("AQ.xxxx")` |

## Didukung

Moodle · Google Forms · Quizizz (semua halaman) · Kahoot · Blooket · Wordwall ·
Liveworksheets · **Extraordinary CBT** (semua domain sekolah, deteksi otomatis
via penanda konten) · situs quiz apapun (deteksi generik).

## Catatan teknis

- `content.js` jalan di **world: MAIN** (Chrome 111+) → request AI ke Groq/Gemini
  berjalan di konteks halaman, perilaku fetch identik dgn userscript.
- `bridge.js` (isolated world) meneruskan key dari `chrome.storage.local` ke
  halaman via postMessage → key gak perlu di-hardcode, gak ikut ke-commit.
- Situs yang udah kebuka pas key disimpan: refresh sekali biar key masuk.
