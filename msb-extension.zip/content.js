/* ============================================================
   MSB Quiz Helper (Grey Ball) — Chrome Extension (MV3)
   Content script world:MAIN. Key diisi lewat POPUP (chrome.storage
   → bridge.js → postMessage) — berlaku di semua situs.
   ============================================================ */


(async function () {
    'use strict';

    /* =========================================================================
       CONFIG — Backend utama = Gemini (key). Fallback = AI lokal Chrome.
       TANPA Puter.

       CHANGELOG 2.3.1 (fix: C sekarang beneran NGESEMBUNYIIN bola):
       - FIX: sebelumnya C cuma flip flag "paksa muncul" → di halaman ada soal bola
           GAK PERNAH ilang (yang hilang cuma perilaku auto-nya).
       - Sekarang C = toggle beneran: bola kelihatan → DISEMBUNYIKAN (di-remove);
           tekan C lagi → muncul lagi. State-nya ke-save (refresh page ikut).
       - Alt+M = toggle yang sama.

       CHANGELOG 2.3.0 (dukungan ALL QUIZIZZ + EXTRAORDINARY CBT):
       - NEW Extraordinary CBT (aplikasi ujian shellrean, dipasang di domain sekolah
         yg beda-beda: cbt.xxx.sch.id / xxx.ac.id) — dideteksi via PENANDA KONTEN
         halaman ("Extraordinary CBT"/"shellrean"), bukan domain → jalan di SEMUA
         instalasi. Halaman ujiannya Bootstrap (.card) + radio input → didukung penuh.
       - NEW guard: input password/field login gak dianggap soal (bola gak nyasar
         nyoba "jawab" halaman login CBT).
       - Quizizz di-broaden: selector baru utk UI terbaru (data-testid, question-box,
         quiz-question, dll) — berlaku di semua halaman quizizz.com + subdomain.
       - matchSite sekarang positive-cache → deteksi konten gak diulang-ulang.

       CHANGELOG 2.2.2 (toggle bola pakai tombol C):
       - NEW: tekan tombol C (tanpa Ctrl/Alt) di halaman = toggle bola — muncul/sembunyi.
         Cuma aktif di LUAR input/textarea (biar ngetik jawaban ber-huruf c gak ke-trigger).
       - Ctrl+C / Cmd+C (copy) TETAP normal — gak ketimpa.
       - C juga ikut ngaktifin proteksi bola 4 dtk (jaga2 kalau situs nyembunyiin
         konten pas C). Alt+M tetap jalan sebagai alternatif.

       CHANGELOG 2.2.1 (fix bola ilang pas pencet TOMBOL SAMPING mouse gaming):
       - Tombol samping mouse (XButton1/XButton2) = Back/Forward + ke-tangkep
         handler anti-copy situs → konten soal disembunyiin sesaat → bola ilang-muncul
         (sama kayak kasus right-click).
       - NEW: right-click, middle-click, dan tombol samping (button 3/4) sekarang
         langsung ngaktifin MODE DILINDUNGI 4 detik — di window itu bola dijamin
         gak dihapus apapun yang terjadi. Listener pasang capture-phase, jadi tetap
         kedengar walau situs stopPropagation.
       - Nyambung sama fix 2.2.0: penghapusan bola butuh 8 cek berurutan kosong.

       CHANGELOG 2.2.0 (fix bola abu-abu ilang pas right-click):
       - PENYEBAB: pas right-click, site/ekstensi (anti-copy / "Visual Modifier")
         sempat nyembunyiin konten soal → deteksi sebentar bilang "gak ada soal" →
         watchdog NGHAPUS bola → right-click lagi konten balik → bola dibangun ulang.
         Efek kek toggle itu.
       - FIX: bola gak dihapus lagi cuma gara-gara 1x cek kosong — butuh 8 cek
         berurutan (±6 detik) beneran gak ada soal baru dihapus. Deteksi kilat-2an
         (right-click, animasi, dll) gak ngaruh lagi.
       - NEW Alt+M = toggle manual paksa-muncul (atau msb.toggle() di console).
         Kalo mode paksa aktif, bola GAK AKAN dihapus apapun yang terjadi.
       - NEW: right-click DI ATAS bola diabaikan — gak nembus ke handler
         anti-right-click site.

       CHANGELOG 2.1.0 (GROQ DIBENERIN BENERAN — root cause ketemu):
       - ROOT CAUSE 404: Groq MENGENSIUNKAN llama-3.3-70b-versatile & llama-3.1-8b-instant
         sejak 16 AGU 2026 buat tier gratis (sumber: console.groq.com/docs/deprecations).
         Key kamu valid — model-nya aja udah mati. BUKAN salah key, BUKAN salah script.
       - FIX: GROQ_MODELS diganti model LIVE (terverifikasi dari daftar deprecation +
         katalog Nov 2026): openai/gpt-oss-120b (utama) → openai/gpt-oss-20b →
         groq/compound-mini → qwen/qwen3.8-27b. Kalau nanti ada yang dipensiunkan lagi,
         katalog auto-detect tetep nyelamatin (self-heal).
       - FIX PENTING: penanda 'dead' lama di localStorage bikin Groq di-skip walau udah
         dibenerin → state sekarang di-VERSIONING; pasang script baru = state bersih.
       - AI_BACKEND default = 'groq': Groq dulu → kalau gagal/kuota abis → Gemini (rotasi
         key) → AI lokal. Kuota free gpt-oss-120b: 1.000 req/hari, 30 req/menit
         (koreksi: 14.400/hari itu angka era llama yang lama).
       - parseAIResponse: buang blok <think>…</think> (gpt-oss = model reasoning).

       CHANGELOG 2.0.0 (MODE UNLIMITED — base: jalur Gemini yang udah terbukti jalan):
       - ⭐ MULTI-KEY GEMINI: GEMINI_API_KEYS jadi ARRAY — tiap key punya kuota gratis
         sendiri (~500/hari flash-lite). 4 key = 2000/hari. Kalo key ke-1 kena 429
         (quota habis) → otomatis rotasi ke key ke-2, dst. Status key disimpan per-hari
         (localStorage), jadi refresh page gak buang percobaan ulang.
       - 401/403 = key invalid → ditandai DEAD & dilewati. 429 = EXHAUSTED → rotasi.
       - AUTO-DISABLE provider macet: backend yang gagal total 2x berturut-turut
         (mis. Groq 404 terus) dimatikan buat sisa hari ini — gak buang waktu lagi.
       - Routing 'auto': Gemini (rotasi key) → Groq → Cerebras → GitHub → Pollinations
         → AI lokal. Urutan mengikuti jalur yang TERBUKTI jalan (Gemini dulu).
       - msb.addGeminiKey('...') tambah key tanpa edit script · msb.status() liat kondisi
         kuota · msb.resetQuota() reset semua penanda 429/dead hari ini.
       - Cache jawaban (jsonblob) tetap aktif: soal yang sama = 0 AI call.
       - MAX_AI_CALLS naik ke 80 biar cukup buat rotasi.

       CHANGELOG 1.5.1 (fix Groq 404):
       - FIX: Groq balikin 404 = model KETUA (dipensiunkan), bukan key salah
         (key salah = 401). Sekarang daftar model Groq/Cerebras/GitHub diambil
         OTOMATIS dari katalog masing-masing (endpoint /models) — model lama yang
         udah dipensiunkan dilewati, yang masih hidup dipakai.
       - Filter model non-chat (whisper/tts/guard/embedding/moderation) dibuang.
       - Model yang terbukti jawab di-cache per provider.

       CHANGELOG 1.5.0 (3 backend pengganti Pollinations — semua key GRATIS):
       - NEW Groq (https://console.groq.com/keys — GRATIS, tanpa kartu): 14.400 req/hari,
         30 req/menit, model llama-3.3-70b-versatile. Pengganti utama Pollinations —
         kuotanya 28x lipat Gemini flash-lite gratis.
       - NEW Cerebras (https://cloud.cerebras.ai — GRATIS): 1 juta token/hari, 30 RPM.
       - NEW GitHub Models (GitHub PAT: github.com/settings/tokens — GRATIS):
         150 req/hari model mini (gpt-4.1-mini dll), 50/hari model besar.
       - Routing 'auto' sekarang: 🖼️ gambar → Gemini (vision) dulu; 📝 teks → Groq dulu
         (kalo ada key) → Gemini flash-lite → Cerebras → GitHub → OpenRouter → lokal.
         Tanpa key Groq/Gemini? Tetap jalan lewat yang lain.
       - Pollinations tetep ada di rantai fallback tapi auto-skip (402 paywall).

       CHANGELOG 1.4.0 (Pollinations paywall + prioritas kuota gratis Gemini):
       - FIX: Pollinations sekarang balikin 402 Payment Required (tier gratis keyless
         dihentikan). Backend ini jadi AUTO-MATI sesi begitu kena 402/403 — gak buang
         waktu 3 request per soal lagi. Kalo suatu saat balik gratis, otomatis kepake lagi.
       - FIX: urutan kandidat Gemini dirombak sesuai KUOTA GRATIS AI Studio (Nov 2026):
           flash-lite  → prioritas #1 (gratis ~500 req/hari, 15 req/menit)
           gemma       → #2 (gratis ~14.000 req/hari)
           flash       → #3 (gratis cuma ~20 req/hari — jadi cadangan)
           pro/ultra   → DIBUANG (kuota gratis 0, pasti 429)
       - Jadi mode 'auto' sekarang efektif: teks → (Polli kalo masih gratis) → Gemini
         flash-lite; gambar → langsung Gemini (vision).

       CHANGELOG 1.3.0 (routing cerdas):
       - NEW mode 'auto' (default sekarang): soal ADA GAMBAR → Gemini dulu (vision,
         Pollinations gak bisa baca gambar); soal TEKS DOANG → Pollinations dulu
         (gratis tanpa key, hemat kuota Gemini). Kalau backend utama gagal/429,
         lanjut otomatis ke backend berikutnya.
       - msb.useGemini() = paksa Gemini dulu untuk SEMUA soal (mode lama).
         msb.useAuto() = balik ke routing cerdas.
       - Catatan kecepatan: Pollinations di-throttle per IP ~1 req/15-45 dtk, jadi
         soal teks banyak agak lambat — tapi gak nguras kuota Gemini.

       CHANGELOG 1.2.0 (option AI GRATIS):
       - NEW backend Pollinations (https://text.pollinations.ai/openai) — TANPA key,
         gratis selamanya (GPT-OSS 20B, text-only). Jadi script jalan walau key kosong.
         Catatan: rate limit per IP, ~1 request / 15-45 detik → cocok buat fallback,
         kalo banyak soal agak lambat.
       - NEW backend OpenRouter (key gratis dari https://openrouter.ai/keys) —
         model :free, ~50 req/hari (naik 1000/hari kalo pernah top-up $10).
         Daftar model :free diambil otomatis dari katalog (model free sering ganti-ganti).
       - Urutan fallback (AI_BACKEND='gemini'/'auto'): Gemini → OpenRouter →
         Pollinations → AI lokal Chrome. Gak punya key apapun? Tetap jalan via Pollinations.
       - Info free tier Gemini (AI Studio, Nov 2026): Flash-Lite ~500 req/hari,
         Flash ~20 req/hari, 5-15 req/menit. Key AI Studio = gratis, tanpa kartu kredit.

       CHANGELOG 1.1.0 (fix "⚠️ Gemini: empty"):
       - Fix: auto-detect model sempat memilih model TTS (mis. gemini-3.8-flash-lite-tts)
         → balikannya kosong. Sekarang model NON-TEKS (tts / imagen / veo / embedding /
         audio / image / vision) dibuang dari daftar kandidat.
       - Fix: kalau satu model gagal (404 / kosong / error), sekarang LANJUT otomatis
         ke kandidat berikutnya sampai dapat yang beneran balikin teks
         (dulu langsung berhenti dan cuma reset cache).
       - Model yang terbukti balikin teks di-cache → soal berikutnya langsung pakai itu.
       ========================================================================= */
    const CONFIG = {
        DEBUG: true,
        STORAGE_KEY: 'msb_sync_blob_id',
        POS_KEY: 'msb_sync_ball_pos',
        BLOB_API: 'https://jsonblob.com/api/jsonBlob',

        AI_BACKEND: 'groq',            // ⭐ 'groq' = GROQ UTAMA (fallback: Gemini → lokal) | 'auto' | 'gemini' | 'cerebras' | 'github' | 'openrouter' | 'pollinations' | 'local'
        /* ⭐ BIAR (HAMPIR) UNLIMITED: isi BANYAK key Gemini di sini — tiap key punya
           kuota gratis sendiri (~500 req/hari flash-lite). Buat key tambahan gratis di
           https://aistudio.google.com/apikey (new project = kuota baru). Auto-rotasi:
           key kena 429 → lanjut key berikutnya. 1 key = 500/hari · 4 key = 2000/hari */
        GEMINI_API_KEYS: [
            ''
        ],
        GEMINI_API_KEY: '',            // (opsional) key tunggal — digabung otomatis ke daftar atas
        OPENROUTER_API_KEY: '',        // (OPSIONAL, key GRATIS) ambil di https://openrouter.ai/keys — model :free ~50 req/hari
        OPENROUTER_FREE_MODELS: [      // prioritas model :free — sisanya auto dari katalog https://openrouter.ai/api/v1/models
            'google/gemini-2.0-flash-exp:free', 'deepseek/deepseek-chat-v3-0324:free', 'meta-llama/llama-3.3-70b-instruct:free'
        ],
        POLLI_MODELS: ['openai-fast', 'openai', 'mistral'],   // Pollinations — SEKARANG 402 PAYWALL buat tier tanpa key; auto-skip pas kena 402

        /* ---- Backend gratis pengganti Pollinations (semua OpenAI-compatible, key GRATIS) ---- */
        GROQ_API_KEY: '',              // ⭐ UTAMA: GRATIS https://console.groq.com/keys — gpt-oss-120b: 1.000 req/hari, 30/menit, tanpa kartu
        GROQ_MODELS: ['openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'groq/compound-mini', 'qwen/qwen3.8-27b'],   // ✅ LIVE Nov 2026 — llama-3.x dipensiunkan Groq 16 Agu 2026 (itu sebabnya 404 kemarin)
        CEREBRAS_API_KEY: '',          // GRATIS di https://cloud.cerebras.ai — 1 juta token/hari, 30 req/menit
        CEREBRAS_MODELS: ['llama-3.3-70b', 'gpt-oss-120b', 'llama3.1-8b'],
        GITHUB_TOKEN: '',              // GRATIS: buat PAT di https://github.com/settings/tokens (tanpa scope) — 150 req/hari model mini
        GITHUB_MODELS: ['openai/gpt-4.1-mini', 'meta/Llama-3.3-70B-Instruct', 'microsoft/Phi-4'],
        GEMINI_MODELS_FALLBACK: [      // dicoba kalau auto-detect gagal total — urut kuota gratis
            'gemini-flash-lite-latest', 'gemini-2.5-flash-lite', 'gemini-flash-latest',
            'gemini-2.5-flash-latest', 'gemini-2.5-flash', 'gemini-2.0-flash'
        ],
        GEMINI_MAX_ATTEMPTS: 5,        // max model kandidat dicoba per soal

        AUTO_SAVE_AI: true,
        MAX_AI_CALLS: 80,
        MAX_IMAGES: 3,
        IMAGE_QUALITY: 0.9,
        MAX_IMAGE_DIM: 1600,
        MAX_IMAGE_KB: 800,
        MIN_APPLY_SCORE: 60,
        MIN_AI_CONFIDENCE: 40,

        MULTI_HINT: /pilih\s*semua|semua\s*yang|select\s*all|all\s*that\s*apply|more\s*than\s*one|lebih\s*dari\s*satu|multiple\s*answer|pilihan\s*ganda\s*kompleks/i
    };

    /* Model yang TIDAK bisa generate teks jawaban — buang dari kandidat */
    const NON_TEXT_MODEL_RE = /tts|imagen|veo|embedding|aqa|audio|live|image|vision/i;
    const MODEL_ALIASES = ['gemini-flash-lite-latest', 'gemini-2.5-flash-lite-latest'];

    /* =========================================================================
       KUOTA / KEY STATE (MODE UNLIMITED)
       - Semua key Gemini digabung & dirotasi. 429 → EXHAUSTED (tidak dipakai lagi
         hari ini), 401/403 → DEAD. State disimpan per-tanggal di localStorage
         supaya refresh page gak mengulang percobaan yang udah gagal.
       - Provider lain (Groq/Cerebras/GitHub/Pollinations) yang gagal total
         berulang juga ditandai DEAD buat hari ini.
       ========================================================================= */
    let geminiKeyIdx = 0;
    function geminiKeys() {
        const ks = (CONFIG.GEMINI_API_KEYS || []).filter(Boolean);
        if (CONFIG.GEMINI_API_KEY && !ks.includes(CONFIG.GEMINI_API_KEY)) ks.push(CONFIG.GEMINI_API_KEY);
        return ks;
    }
    const KEY_STATE_LS = 'msb_key_state';
    const KEY_STATE_VERSION = 'v2.1';   // 👈 ganti versi script = state lama dibuang (mis. 'Groq' yang salah ditandai dead kemarin)
    function dayStamp() { return new Date().toISOString().slice(0, 10); }
    function freshKeyState() { return { v: KEY_STATE_VERSION, day: dayStamp(), exhausted: {}, dead: {} }; }
    function loadKeyState() { try { const s = JSON.parse(localStorage.getItem(KEY_STATE_LS) || 'null'); return (s && s.v === KEY_STATE_VERSION && s.day === dayStamp()) ? s : freshKeyState(); } catch (e) { return freshKeyState(); } }
    let keyState = freshKeyState();          // di-refresh ulang di init()
    function saveKeyState() { try { localStorage.setItem(KEY_STATE_LS, JSON.stringify(keyState)); } catch (e) {} }
    function maskKey(k) { return k ? (k.slice(0, 6) + '…' + k.slice(-4)) : '(kosong)'; }
    function liveGeminiKeys() {
        const keys = geminiKeys();
        const live = keys.map((k, i) => ({ k, i })).filter(o => !keyState.exhausted[o.i] && !keyState.dead[o.i]);
        return { keys, live };
    }
    const provFailCount = {};                // hitung kegagalan total berturut-turut per provider
    function noteProvFail(name, max = 2) {
        provFailCount[name] = (provFailCount[name] || 0) + 1;
        if (provFailCount[name] >= max) {
            keyState.dead[name] = true; saveKeyState();
            log(`🚫 ${name} gagal ${max}x berturut-turut — dimatikan buat sisa hari ini (msb.resetQuota() buat reset)`);
        }
    }
    function noteProvOk(name) { provFailCount[name] = 0; }

    const SITES = {
        'smaialazhar33.sch.id': { questionSelector: '.que', questionTextSel: '.qtext' },
        'moodle': { questionSelector: '.que', questionTextSel: '.qtext' },
        'docs.google.com': { questionSelector: '.freebirdFormviewerViewItemsItemItem', questionTextSel: '.freebirdFormviewerViewItemsItemTitle' },
        'forms.gle': { questionSelector: '.freebirdFormviewerViewItemsItemItem', questionTextSel: '.freebirdFormviewerViewItemsItemItemTitle' },
        'quizizz.com': { questionSelector: '[class*="question-container" i], [data-question], [class*="questionScreen" i], [data-testid*="question" i], [class*="question-box" i], [class*="quiz-question" i], [class*="questionCard" i]', questionTextSel: '[class*="question-text" i], [class*="questionText" i], [data-testid*="question-text" i], [class*="question-content" i]' },
        'quizizz.link': { questionSelector: '[class*="question-container" i], [data-question], [class*="questionScreen" i], [data-testid*="question" i]' },
        'kahoot.it': { questionSelector: '[class*="question" i]' },
        'kahoot.com': { questionSelector: '[class*="question" i]' },
        'blooket.com': { questionSelector: '[class*="question" i], [class*="answer" i]' },
        'wordwall.net': { questionSelector: '[class*="question" i], [class*="activity" i]' },
        'liveworksheets.com': { questionSelector: '.quiz, .question, form' },
        /* Extraordinary CBT (shellrean) — domain per-sekolah beda2 (cbt.xxx.sch.id),
           dikenali lewat penanda konten di matchSite(). Halaman ujian = Bootstrap
           card + radio/checkbox/textarea (didukung deteksi generik). */
        'extraordinary-cbt': { questionSelector: '.card, .card-body', questionTextSel: '.card-body h5, .card-body .soal, .card-body [class*="soal" i], .card-body [class*="question" i]' },
        'extracbt': { questionSelector: '.card, .card-body', questionTextSel: '.card-body h5, .card-body .soal, .card-body [class*="soal" i], .card-body [class*="question" i]' }
    };

    const log = (...a) => CONFIG.DEBUG && console.log('[MSB]', ...a);
    const q = (sel, root = document) => root.querySelector(sel);
    const qa = (sel, root = document) => [...root.querySelectorAll(sel)];

    let state = { blobId: null, database: {}, busy: false, aiCallCount: 0, watchdogTimer: null, domObserver: null, lastBody: null, localSession: null };
    let geminiModelCache = null;

    function waitForDOM() { return new Promise(r => { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', r, { once: true }); else r(); }); }
    function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
    function norm(s) { return (s || '').replace(/\s+/g, ' ').replace(/[^\w\s]/g, '').trim().toLowerCase(); }
    function cleanText(s) { return (s || '').replace(/\s+/g, ' ').trim(); }
    /* matchSite — hostname dulu, lalu penanda KONTEN (utk Extraordinary CBT dkk yg
       domain-nya bebas per-sekolah). Hasil positif di-cache biar gak scan terus. */
    let siteCache = null;
    function matchSite() {
        if (siteCache) return siteCache;
        const h = location.hostname.toLowerCase();
        for (const key in SITES) { if (h.includes(key.toLowerCase())) return (siteCache = SITES[key]); }
        try {
            const marker = document.body ? (document.body.innerText || '').slice(0, 4000) : '';
            if (/extraordinary[\s_-]*cbt/i.test(marker) || /shellrean/i.test(marker)) return (siteCache = SITES['extraordinary-cbt']);
        } catch (e) {}
        return null;
    }
    function hashQ(text) { const c = norm(text); let h = 5381; for (let i = 0; i < c.length; i++) { h = ((h << 5) + h) + c.charCodeAt(i); h = h & h; } return 'q_' + Math.abs(h).toString(36); }

    /* =========================================================================
       CSS
       ========================================================================= */
    const STYLES = `
        #msb-container { position: fixed; bottom: 16px; right: 16px; display: flex; flex-direction: column; gap: 8px; z-index: 999998; user-select: none; -webkit-tap-highlight-color: transparent; }
        .msb-btn { width: 28px; height: 28px; border-radius: 50%; border: none; cursor: pointer; padding: 0; transition: transform 0.15s ease, background 0.2s ease; display: flex; align-items: center; justify-content: center; font-family: -apple-system, 'Segoe UI', Arial, sans-serif; font-size: 15px; font-weight: 700; position: relative; }
        .msb-btn:hover { transform: scale(1.1); }
        .msb-btn:active { transform: scale(0.9); }
        #msb-btn-answer { background: #808080; box-shadow: 0 3px 10px rgba(0,0,0,0.25); color: transparent; }
        #msb-btn-undo { background: #ffffff; border: 1.5px solid #e74c3c; color: #e74c3c; box-shadow: 0 3px 10px rgba(231,76,60,0.2); }
        #msb-btn-undo:hover { background: #fff5f5; }
        #msb-badge { position: absolute; top: -4px; right: -4px; background: #fff; color: #000; font-size: 7px; font-weight: 800; padding: 1px 3px; border-radius: 6px; min-width: 11px; height: 11px; display: flex; align-items: center; justify-content: center; border: 1px solid #666; line-height: 1; font-family: -apple-system, 'Segoe UI', Arial, sans-serif; }
        #msb-badge.hidden { display: none; }
        .msb-toast { position: fixed; top: 16px; right: 16px; padding: 8px 14px; border-radius: 6px; color: white; font-family: -apple-system, 'Segoe UI', Arial, sans-serif; font-size: 11px; font-weight: 500; z-index: 1000000; box-shadow: 0 3px 14px rgba(0,0,0,0.2); max-width: 340px; line-height: 1.35; animation: msbSlideIn 0.22s ease; background: #0a0a0a; border: 1px solid #333; }
        @keyframes msbSlideIn { from { opacity: 0; transform: translateX(15px); } to { opacity: 1; transform: translateX(0); } }
        .msb-mark { display: inline-block; margin-left: 6px; font-size: 13px; font-weight: 700; vertical-align: middle; font-family: -apple-system, 'Segoe UI', Arial, sans-serif; }
        .msb-mark.ok { color: #11998e; }
        .msb-mark.fail { color: #c62828; }
        .msb-mark.warn { color: #ff9800; }
        .msb-mark.img { color: #2196f3; }
    `;
    function injectStyles() { if (document.getElementById('msb-styles')) return; const s = document.createElement('style'); s.id = 'msb-styles'; s.textContent = STYLES; (document.head || document.documentElement).appendChild(s); }
    function toast(msg, dur = 2500) { const t = document.createElement('div'); t.className = 'msb-toast'; t.textContent = msg; (document.body || document.documentElement).appendChild(t); setTimeout(() => { t.style.transition = 'opacity 0.25s, transform 0.25s'; t.style.opacity = '0'; t.style.transform = 'translateX(10px)'; setTimeout(() => t.remove(), 250); }, dur); }

    /* =========================================================================
       GENERIC DETECTION
       ========================================================================= */
    function isClickableOption(el) {
        if (!el || el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') return false;
        const txt = (el.innerText || '').trim(); if (txt.length < 1 || txt.length > 250) return false;
        if (el.querySelectorAll('*').length > 25) return false;
        if (el.querySelector('input[type="radio"], input[type="checkbox"], [role="radio"], [role="checkbox"], [class*="option" i]')) return false;
        const role = (el.getAttribute && el.getAttribute('role')) || '';
        if (role === 'radio' || role === 'checkbox' || role === 'button' || role === 'option') return true;
        if (el.tagName === 'BUTTON' || el.tagName === 'A') return true;
        const cls = (el.className || '').toString().toLowerCase();
        if (/(^|\s)(option|answer|choice|alt|variant|selection)/.test(cls)) return true;
        try { if (getComputedStyle(el).cursor === 'pointer' || el.onclick) return true; } catch (e) {}
        return false;
    }
    function findQuestionRoot(el) {
        let node = el;
        while (node && node !== document.body && node.parentElement) {
            const cls = (node.className || '').toString().toLowerCase(); const id = (node.id || '').toLowerCase(); const role = node.getAttribute && node.getAttribute('role');
            if (/(^|\s)(question|que|prompt|quiz|problem|item|stem|qtext|q-text|card|fieldset|exercise|task)/.test(cls + ' ' + id) || role === 'question' || role === 'group' || role === 'radiogroup' || role === 'listitem') return node;
            node = node.parentElement;
        }
        return el.closest('form, li, [role="listitem"], section, article, fieldset') || el.parentElement || el;
    }
    function collectOptions(scope) {
        const sels = ['input[type="radio"]:not([disabled])', 'input[type="checkbox"]:not([disabled])', '[role="radio"]:not([aria-disabled="true"])', '[role="checkbox"]:not([aria-disabled="true"])'];
        let els = qa(sels.join(','), scope);
        qa('[class*="option" i]:not([class*="options" i]), [class*="answer" i]:not([class*="answers" i]), [class*="choice" i], [data-testid*="option" i], button.option', scope).forEach(d => { if (isClickableOption(d)) els.push(d); });
        return els;
    }
    function detectQuestions() {
        const site = matchSite();
        if (site && site.questionSelector) { const els = qa(site.questionSelector); if (els.length) return dedupeRoots(els); }
        const optionEls = collectOptions(document); const roots = new Map();
        for (const el of optionEls) { const r = findQuestionRoot(el); if (r) roots.set(r, (roots.get(r) || 0) + 1); }
        let list = [...roots.keys()]; if (list.length) return dedupeRoots(list);
        return collectTextQuestions(document);
    }
    function dedupeRoots(list) { const out = []; for (const r of list) { if (out.some(o => o.contains(r) || r.contains(o))) continue; out.push(r); } return out; }
    function collectTextQuestions(scope) {
        const site = matchSite();
        const texts = qa('textarea:not([readonly]):not([disabled]), input[type="text"]:not([readonly]):not([disabled]), input[type="email"]:not([disabled]), input[type="number"]:not([disabled])', scope)
            .filter(t => {   // 👈 skip field login (bola gak boleh nyasar "jawab" halaman login CBT)
                const id = ((t.id || '') + ' ' + (t.name || '') + ' ' + (t.placeholder || '')).toLowerCase();
                return !/pass|sandi|confirm|captcha/i.test(id);
            });
        if (!texts.length) return []; const roots = new Map();
        for (const t of texts) { const r = t.closest('form, li, [role="listitem"], section, article, fieldset, .freebirdFormviewerViewItemsItemItem, .card') || t.parentElement; if (r) roots.set(r, (roots.get(r) || 0) + 1); }
        return dedupeRoots([...roots.keys()]);
    }
    function getQuestionText(root) {
        const site = matchSite();
        if (site && site.questionTextSel) { const t = q(site.questionTextSel, root); if (t) return cleanText(t.innerText); }
        const cands = qa('[class*="question-text" i],[class*="questionText" i],[class*="prompt" i],[class*="stem" i],[class*="qtext" i],h1,h2,h3,h4,p,[role="heading"]', root);
        for (const c of cands) { const txt = cleanText(c.innerText); if (txt.length > 5) return txt; }
        const clone = root.cloneNode(true); clone.querySelectorAll('input,select,textarea,button,[class*="option" i],[class*="answer" i],[role="radio"],[role="checkbox"],svg').forEach(n => n.remove());
        return cleanText(clone.innerText);
    }
    function getQuestionTextEl(root) {
        const site = matchSite();
        if (site && site.questionTextSel) { const t = q(site.questionTextSel, root); if (t) return t; }
        const cands = qa('[class*="question-text" i],[class*="questionText" i],[class*="prompt" i],[class*="stem" i],[class*="qtext" i],h1,h2,h3,h4,p,[role="heading"]', root);
        for (const c of cands) { if (cleanText(c.innerText).length > 5) return c; }
        return root;
    }
    function getLabelText(input, qEl) {
        let label = input.id ? qEl.querySelector(`label[for="${input.id}"]`) : null;
        if (!label) label = input.closest('label'); if (!label) label = input.parentElement; if (!label) return '';
        const clone = label.cloneNode(true); clone.querySelectorAll('input,select,textarea').forEach(n => n.remove());
        return clone.innerText.trim().replace(/\s+/g, ' ');
    }
    function getOptionText(el, root) {
        if (!el) return '';
        if (el.tagName === 'INPUT') return getLabelText(el, root);
        if (el.tagName === 'SELECT') return (el.selectedOptions[0]?.textContent || el.options[el.selectedIndex]?.textContent || '').trim();
        if (el.tagName === 'TEXTAREA') return el.value;
        const clone = el.cloneNode(true); clone.querySelectorAll('input,select,textarea,svg,img,[class*="icon" i],[class*="mark" i]').forEach(n => n.remove());
        return clone.innerText.trim().replace(/\s+/g, ' ');
    }
    function isPlaceholderOption(text) { if (!text) return true; const t = text.trim().toLowerCase(); if (t === '') return true; return /^(choose|pilih|select|--|\.\.\.)/i.test(t); }
    function detectQuestionType(root) {
        const radios = qa('input[type="radio"]:not([disabled])', root).filter(r => getOptionText(r, root).length > 0);
        const checks = qa('input[type="checkbox"]:not([disabled])', root).filter(c => getOptionText(c, root).length > 0);
        const selects = qa('select:not([disabled])', root).filter(sel => Array.from(sel.options).some(o => o.textContent.trim() && !isPlaceholderOption(o.textContent)));
        const divOpts = qa('[role="radio"],[role="checkbox"],[class*="option" i]:not([class*="options" i]),[class*="answer" i]:not([class*="answers" i]),[class*="choice" i]', root).filter(e => isClickableOption(e) && !e.querySelector('input'));
        const qText = getQuestionText(root); const isMulti = CONFIG.MULTI_HINT.test(qText);
        const build = (list) => list.map((el, idx) => ({ idx, letter: String.fromCharCode(97 + idx), text: getOptionText(el, root), el, input: el.tagName === 'INPUT' ? el : null })).filter(o => o.text);
        if (checks.length >= 2) return { type: 'checkbox', multi: true, options: build(checks), inputEl: null, selectEl: null };
        if (radios.length >= 2) return { type: 'radio', multi: false, options: build(radios), inputEl: null, selectEl: null };
        if (divOpts.length >= 2) return { type: isMulti ? 'checkbox' : 'radio', multi: isMulti, options: build(divOpts), inputEl: null, selectEl: null };
        if (selects.length >= 1) {
            const sel = selects[0]; const opts = Array.from(sel.options).filter(o => o.textContent.trim() && !isPlaceholderOption(o.textContent)).map(o => ({ text: o.textContent.trim(), value: o.value }));
            return { type: 'select', multi: false, options: opts.map((o, i) => ({ idx: i, letter: String.fromCharCode(97 + i), text: o.text, el: sel, input: null })), inputEl: null, selectEl: sel };
        }
        const ta = q('textarea:not([readonly]):not([disabled])', root); if (ta) return { type: 'textarea', multi: false, options: [], inputEl: ta, selectEl: null };
        const ti = q('input[type="text"]:not([readonly]):not([disabled]), input[type="email"]:not([disabled]), input[type="number"]:not([disabled])', root); if (ti) return { type: 'text', multi: false, options: [], inputEl: ti, selectEl: null };
        return { type: 'unknown', multi: false, options: [], inputEl: null, selectEl: null };
    }
    function extractQuestionContent(root) {
        const result = { text: '', images: [], typeInfo: null, options: [] };
        result.typeInfo = detectQuestionType(root); result.text = getQuestionText(root); result.options = result.typeInfo.options;
        const seen = new Set();
        qa('img', root).forEach(img => {
            const src = img.src || img.getAttribute('data-src'); if (!src || seen.has(src)) return;
            if (img.width > 0 && img.width < 80 && img.height > 0 && img.height < 80) return;
            if (src.includes('/icon') || src.includes('icon_')) return; if (src.startsWith('data:image/gif')) return;
            seen.add(src); result.images.push({ src, alt: img.alt || '', width: img.naturalWidth || img.width, height: img.naturalHeight || img.height });
        });
        result.images.sort((a, b) => (b.width * b.height) - (a.width * a.height)); result.images = result.images.slice(0, CONFIG.MAX_IMAGES);
        return result;
    }

    /* =========================================================================
       UNDO / CLEAR ALL
       ========================================================================= */
    function undoAll() {
        let cleared = 0;
        document.querySelectorAll('.msb-mark').forEach(m => { m.remove(); cleared++; });
        document.querySelectorAll('input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled])').forEach(inp => { if (inp.checked) { inp.checked = false; inp.dispatchEvent(new Event('change', { bubbles: true })); inp.dispatchEvent(new Event('input', { bubbles: true })); cleared++; } });
        document.querySelectorAll('[aria-selected="true"],[aria-checked="true"]').forEach(el => { el.removeAttribute('aria-selected'); el.removeAttribute('aria-checked'); cleared++; });
        document.querySelectorAll('select:not([disabled])').forEach(sel => { let ph = 0; for (let i = 0; i < sel.options.length; i++) { const opt = sel.options[i]; if (!opt.value || isPlaceholderOption(opt.textContent)) { ph = i; break; } } if (sel.selectedIndex !== ph) { sel.selectedIndex = ph; sel.dispatchEvent(new Event('change', { bubbles: true })); sel.dispatchEvent(new Event('input', { bubbles: true })); cleared++; } });
        document.querySelectorAll('input[type="text"]:not([readonly]):not([disabled]), input[type="email"]:not([disabled]), input[type="number"]:not([disabled])').forEach(inp => { if (inp.value) { inp.value = ''; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); cleared++; } });
        document.querySelectorAll('textarea:not([readonly]):not([disabled])').forEach(ta => { if (ta.value) { ta.value = ''; ta.dispatchEvent(new Event('input', { bubbles: true })); ta.dispatchEvent(new Event('change', { bubbles: true })); cleared++; } });
        log(`↺ Undo: ${cleared} element cleared`); toast(cleared > 0 ? `↺ ${cleared} jawaban dihapus` : '↺ Tidak ada yg perlu dihapus', cleared > 0 ? 2000 : 1500);
    }

    /* =========================================================================
       BLOB API
       ========================================================================= */
    async function newBlob() { try { const r = await fetch(CONFIG.BLOB_API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) }); const loc = r.headers.get('Location') || r.headers.get('location'); return loc ? loc.split('/').pop() : null; } catch (e) { return null; } }
    async function readDB(id) { if (!id) return {}; try { const r = await fetch(`${CONFIG.BLOB_API}/${id}`, { headers: { 'Accept': 'application/json' } }); if (!r.ok) return {}; const d = await r.json(); return d && typeof d === 'object' ? d : {}; } catch (e) { return {}; } }
    async function writeDB(id, data) { if (!id) return false; try { const r = await fetch(`${CONFIG.BLOB_API}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(data) }); return r.ok; } catch (e) { return false; } }

    /* =========================================================================
       IMAGE HELPERS
       ========================================================================= */
    function loadImage(src) { return new Promise(resolve => { if (src.startsWith('data:')) { const img = new Image(); img.onload = () => resolve(img); img.onerror = () => resolve(null); img.src = src; return; } const img = new Image(); img.crossOrigin = 'anonymous'; const timeout = setTimeout(() => resolve(null), 5000); img.onload = () => { clearTimeout(timeout); resolve(img); }; img.onerror = () => { clearTimeout(timeout); resolve(null); }; img.src = src; }); }
    function imgElementToBase64(img) { try { let w = img.naturalWidth || img.width, h = img.naturalHeight || img.height; const canvas = document.createElement('canvas'); if (w > CONFIG.MAX_IMAGE_DIM || h > CONFIG.MAX_IMAGE_DIM) { const scale = CONFIG.MAX_IMAGE_DIM / Math.max(w, h); w = Math.floor(w * scale); h = Math.floor(h * scale); } canvas.width = w; canvas.height = h; const ctx = canvas.getContext('2d'); ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.drawImage(img, 0, 0, w, h); let q = CONFIG.IMAGE_QUALITY, dataUrl = canvas.toDataURL('image/jpeg', q); while (dataUrl.length > CONFIG.MAX_IMAGE_KB * 1024 && q > 0.5) { q -= 0.1; dataUrl = canvas.toDataURL('image/jpeg', q); } return dataUrl; } catch (e) { return null; } }
    async function combineImagesToBase64(images) {
        if (!images.length) return null;
        try {
            const loaded = []; for (const imgData of images) { const img = await loadImage(imgData.src); if (img) loaded.push(img); } if (!loaded.length) return null;
            if (loaded.length === 1) return imgElementToBase64(loaded[0]);
            const pad = 20, labelH = 24; const maxW = Math.max(...loaded.map(l => l.naturalWidth || l.width)); const totalH = loaded.reduce((s, l) => s + (l.naturalHeight || l.height) + pad, 0);
            const canvas = document.createElement('canvas'); canvas.width = maxW; canvas.height = totalH + loaded.length * labelH; const ctx = canvas.getContext('2d'); ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
            let y = 0; loaded.forEach((l, i) => { ctx.fillStyle = '#000'; ctx.font = 'bold 14px Arial'; ctx.fillText(`Image ${i + 1}`, 8, y + 18); y += labelH; ctx.drawImage(l, 0, y); y += (l.naturalHeight || l.height) + pad; });
            let rc = canvas; if (canvas.width > CONFIG.MAX_IMAGE_DIM || canvas.height > CONFIG.MAX_IMAGE_DIM) { const scale = CONFIG.MAX_IMAGE_DIM / Math.max(canvas.width, canvas.height); const nc = document.createElement('canvas'); nc.width = Math.floor(canvas.width * scale); nc.height = Math.floor(canvas.height * scale); const nctx = nc.getContext('2d'); nctx.fillStyle = '#ffffff'; nctx.fillRect(0, 0, nc.width, nc.height); nctx.drawImage(canvas, 0, 0, nc.width, nc.height); rc = nc; }
            let q = CONFIG.IMAGE_QUALITY, dataUrl = rc.toDataURL('image/jpeg', q); while (dataUrl.length > CONFIG.MAX_IMAGE_KB * 1024 && q > 0.5) { q -= 0.1; dataUrl = rc.toDataURL('image/jpeg', q); } return dataUrl;
        } catch (e) { log('❌ Combine error:', e); return null; }
    }

    /* =========================================================================
       PROMPT / PARSE
       ========================================================================= */
    function buildPrompt(content) {
        const t = content.typeInfo; const hasImg = content.images.length > 0;
        let p = `You are an expert exam solver. Answer ACCURATELY. DO NOT GUESS.\n\n`;
        if (hasImg) p += `⚠️ ${content.images.length} image(s) attached. READ THE IMAGES CAREFULLY first.\n\n`;
        p += `=== QUESTION TEXT ===\n${content.text || '(no text — see image)'}\n`;
        if (t.type === 'radio' || t.type === 'div') { p += `\n=== TYPE: SINGLE CHOICE ===\nOPTIONS:\n`; t.options.forEach(o => p += `${o.letter}. ${o.text}\n`); p += `\nOUTPUT:\n<letter>. <exact text>\n<confidence>\n<reason>\n`; }
        else if (t.type === 'checkbox') { p += `\n=== TYPE: MULTIPLE ANSWERS ===\nOPTIONS:\n`; t.options.forEach(o => p += `${o.letter}. ${o.text}\n`); p += `\nOUTPUT:\n<letter>, <letter>\n<confidence>\n<reason>\n`; }
        else if (t.type === 'select') { const opts = t.options.map(o => o.text); p += `\n=== TYPE: DROPDOWN ===\nChoices: ${opts.map(o => `"${o}"`).join(' OR ')}\nOUTPUT:\n<exact choice>\n<confidence>\n<reason>\n`; }
        else if (t.type === 'text') { p += `\n=== SHORT ANSWER ===\nOUTPUT:\n<answer>\n<confidence>\n<reason>\n`; }
        else if (t.type === 'textarea') { p += `\n=== ESSAY ===\nOUTPUT:\n<answer>\n<confidence>\n<reason>\n`; }
        else { p += `\n=== TYPE: UNKNOWN ===\nOPTIONS:\n` + t.options.map(o => `${o.letter}. ${o.text}\n`).join('') + `OUTPUT:\n<letter or answer>\n<confidence>\n<reason>\n`; }
        return p;
    }
    function parseAIResponse(rawText) {
        let t = String(rawText || '').replace(/<think>[\s\S]*?<\/think>/gi, '').trim(); let answer = '', confidence = 50, reasoning = '';   // buang blok reasoning <think> (gpt-oss)
        const lines = t.split('\n').map(l => l.trim()).filter(l => l); if (!lines.length) return { error: 'empty' };
        answer = lines[0].replace(/^(final\s*answer|answer|jawaban)[:\s]*/i, '').replace(/^["'`]+|["'`]+$/g, '').trim();
        for (let i = 1; i < Math.min(lines.length, 4); i++) { const m = lines[i].match(/(\d{1,3})\s*%?/); if (m) { const n = parseInt(m[1]); if (n >= 0 && n <= 100) { confidence = n; break; } } }
        reasoning = lines.slice(2).join(' ').substring(0, 200); if (answer.length > 500) answer = answer.substring(0, 500);
        return { answer, confidence, reasoning };
    }

    /* =========================================================================
       BACKEND 1: GEMINI CLOUD (key)
       — Auto-detect HANYA model teks (bukan TTS/imagen/veo/embedding).
       — Kalau satu model gagal/404/balikan kosong → lanjut kandidat berikutnya.
       — Model yang terbukti jalan di-cache (geminiModelCache).
       ========================================================================= */
    function scoreGeminiModel(name) {
        // Prioritas berdasar KUOTA GRATIS AI Studio (Nov 2026):
        //   flash-lite ~500 req/hari · gemma ~14.000/hari · flash ~20/hari · pro/ultra 0 (paid only)
        let s = 0;
        const v = name.match(/gemini-(\d+)(?:[.-](\d+))?/);
        if (v) s += parseFloat(`${v[1]}.${v[2] || 0}`) * 10;   // versi terbaru dulu
        if (/flash-lite/.test(name)) s += 40;                   // kuota gratis terbesar di rumpun gemini
        else if (/gemma/.test(name)) s += 30;                   // gemma: gratis beneran, 14k/hari
        else if (/flash/.test(name)) s += 25;                   // flash: cuma ~20/hari — cadangan
        if (/(pro|ultra)/.test(name)) s -= 1000;                // kuota gratis 0 → skip total
        if (/(preview|exp|thinking)/.test(name)) s -= 15;       // eksperimental → discount dikit
        if (MODEL_ALIASES.includes(name)) s += 30;
        return s;
    }
    async function getGeminiModelCandidates() {
        if (geminiModelCache) return [geminiModelCache];   // ✅ sudah ketemu yang jalan
        const { keys } = liveGeminiKeys();
        if (!keys.length) return [];
        // pakai key yang masih hidup buat fetch katalog
        const k0 = (liveGeminiKeys().live[0] || { k: keys[0] }).k;
        let fromApi = [];
        try {
            const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(k0)}`);
            if (res.ok) {
                const json = await res.json();
                fromApi = (json.models || [])
                    .filter(m => (m.supportedGenerationMethods || []).includes('generateContent'))
                    .map(m => (m.name || '').replace(/^models\//, ''))
                    .filter(n => n && !NON_TEXT_MODEL_RE.test(n));   // 👈 buang TTS/imagen/veo/embedding/audio dll.
            }
        } catch (e) { log('⚠️ Gagal fetch daftar model:', e); }
        const seen = new Set(); const out = [];
        fromApi.sort((a, b) => scoreGeminiModel(b) - scoreGeminiModel(a)).forEach(n => { if (!seen.has(n)) { seen.add(n); out.push(n); } });
        for (const m of CONFIG.GEMINI_MODELS_FALLBACK) { if (!seen.has(m)) { seen.add(m); out.push(m); } }
        log('🤖 Kandidat model (urut prioritas):', out.slice(0, 6).join(', '), out.length > 6 ? `+${out.length - 6} lagi` : '');
        return out;
    }
    async function askAIGemini(content) {
        const { keys, live } = liveGeminiKeys();
        if (!keys.length) return { error: 'GEMINI_API_KEY kosong' };
        if (!live.length) return { error: 'Semua key Gemini exhausted/dead hari ini — lanjut provider lain' };
        if (state.aiCallCount >= CONFIG.MAX_AI_CALLS) return { error: 'Batas AI call' };
        const prompt = buildPrompt(content);
        const hasImages = content.images.length > 0;
        let imageData = null; if (hasImages) imageData = await combineImagesToBase64(content.images);
        const candidates = await getGeminiModelCandidates();
        if (!candidates.length) return { error: 'gagal tentukan model Gemini' };

        // rotasi round-robin: mulai dari key berikutnya yang terakhir dipakai
        const start = geminiKeyIdx % live.length;
        const ordered = live.slice(start).concat(live.slice(0, start));

        let lastErr = 'unknown';
        for (const { k, i } of ordered) {
            const models = (geminiModelCache ? [geminiModelCache] : candidates.slice(0, CONFIG.GEMINI_MAX_ATTEMPTS));
            for (const model of models) {
                if (state.aiCallCount >= CONFIG.MAX_AI_CALLS) break;
                const parts = [{ text: prompt }];
                if (hasImages && imageData) { const m = imageData.match(/^data:(.+?);base64,(.+)$/); if (m) parts.push({ inlineData: { mimeType: m[1], data: m[2] } }); }
                state.aiCallCount++;
                try {
                    log(`🤖 [Gemini] key#${i + 1} ${maskKey(k)} → ${model}${hasImages ? ' 👁️' : ''} [${state.aiCallCount}/${CONFIG.MAX_AI_CALLS}]`);
                    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(k)}`;
                    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts }], generationConfig: { temperature: 0.2, maxOutputTokens: 2048 } }) });
                    if (res.status === 429) {   // kuota key ini habis → tandai & ROTASI ke key berikutnya
                        keyState.exhausted[i] = true; saveKeyState();
                        lastErr = `key#${i + 1} kuota habis (429) — ${Object.keys(keyState.exhausted).length} key exhausted hari ini`;
                        log('⚠️ Gemini', lastErr);
                        break;   // keluar loop model → lanjut key berikutnya
                    }
                    if (res.status === 401 || res.status === 403) {   // key invalid → DEAD
                        keyState.dead[i] = true; saveKeyState();
                        lastErr = `key#${i + 1} invalid (${res.status}) — dilewati`;
                        log('⚠️ Gemini', lastErr);
                        break;
                    }
                    if (!res.ok) {
                        const tb = await res.text();
                        if (res.status === 404 && geminiModelCache === model) geminiModelCache = null;   // model pensiun → reset cache
                        lastErr = `${model}: HTTP ${res.status} ${tb.substring(0, 90)}`;
                        log('❌', lastErr);
                        continue;
                    }
                    const json = await res.json();
                    const cand = json?.candidates?.[0];
                    const text = (cand?.content?.parts || []).filter(p => p.text && !p.thought).map(p => p.text).join('');
                    if (!text.trim()) {
                        const why = json?.promptFeedback?.blockReason || cand?.finishReason || 'empty';
                        lastErr = `${model}: balikan kosong (${why})`;
                        log('⚠️', lastErr);
                        continue;
                    }
                    geminiModelCache = model; geminiKeyIdx = i + 1;   // ✅ key berikutnya mulai dari sini (beban merata)
                    log('✅ Model aktif:', model, '| key#' + (i + 1));
                    const parsed = parseAIResponse(text); if (parsed.error) return parsed;
                    return { ...parsed, model: 'gemini:' + model };
                } catch (e) { lastErr = `${model}: ${String(e).slice(0, 80)}`; log('❌', lastErr); }
            }
        }
        return { error: 'Gemini gagal — ' + lastErr };
    }

    /* =========================================================================
       BACKEND 2: OPENROUTER (key GRATIS) — model :free, auto dari katalog
       Ambil key gratis: https://openrouter.ai/keys (tanpa kartu kredit)
       Limit: 20 req/menit, 50 req/hari (naik 1000/hari kalo pernah top-up $10 sekali)
       ========================================================================= */
    let openRouterModelsCache = null;
    async function getOpenRouterFreeModels() {
        if (openRouterModelsCache) return openRouterModelsCache;
        try {
            const res = await fetch('https://openrouter.ai/api/v1/models');
            if (res.ok) {
                const json = await res.json();
                const free = (json.data || []).map(m => m.id).filter(id => id && id.endsWith(':free'));
                const prefer = CONFIG.OPENROUTER_FREE_MODELS.filter(m => free.includes(m));
                const rest = free.filter(m => !prefer.includes(m)).sort();
                openRouterModelsCache = [...prefer, ...rest];
                log('🟣 OpenRouter model :free tersedia:', openRouterModelsCache.length);
                return openRouterModelsCache;
            }
        } catch (e) { log('⚠️ Gagal fetch katalog OpenRouter:', e); }
        openRouterModelsCache = CONFIG.OPENROUTER_FREE_MODELS.slice();
        return openRouterModelsCache;
    }
    async function askAIOpenRouter(content) {
        if (!CONFIG.OPENROUTER_API_KEY) return { error: 'OPENROUTER_API_KEY kosong' };
        if (state.aiCallCount >= CONFIG.MAX_AI_CALLS) return { error: 'Batas AI call' };
        const prompt = buildPrompt(content);
        const models = (await getOpenRouterFreeModels()).slice(0, CONFIG.GEMINI_MAX_ATTEMPTS);
        if (!models.length) return { error: 'gagal tentukan model OpenRouter' };
        let lastErr = 'unknown';
        for (const model of models) {
            state.aiCallCount++;
            try {
                log(`🟣 [OpenRouter] coba ${model} [${state.aiCallCount}/${CONFIG.MAX_AI_CALLS}]`);
                const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + CONFIG.OPENROUTER_API_KEY },
                    body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], temperature: 0.2, max_tokens: 1024 })
                });
                if (!res.ok) { lastErr = `${model}: HTTP ${res.status}`; log('❌', lastErr); continue; }
                const json = await res.json();
                const text = json?.choices?.[0]?.message?.content || '';
                if (!text.trim()) { lastErr = `${model}: balikan kosong`; log('⚠️', lastErr); continue; }
                openRouterModelsCache = [model];   // ✅ cache model yang jalan
                const parsed = parseAIResponse(text); if (parsed.error) return parsed;
                return { ...parsed, model: 'openrouter:' + model };
            } catch (e) { lastErr = `${model}: ${String(e).slice(0, 80)}`; log('❌', lastErr); }
        }
        return { error: 'Semua model :free gagal — ' + lastErr };
    }

    /* =========================================================================
       BACKEND UNIVERSAL: OpenAI-compatible (Groq / Cerebras / GitHub Models)
       Ketiganya key GRATIS tanpa kartu kredit — tinggal isi CONFIG di atas.
       Daftar model AUTO-DETECT dari katalog provider (model lama sering dipensiunkan
       → 404 kalau di-hardcode; katalog selalu update).
       ========================================================================= */
    const providerModelCaches = {};   // per-provider cache daftar/model aktif
    const NON_CHAT_MODEL_RE = /whisper|tts|guard|embed|safety|moderation|speech|distil|prompt-/i;
    function scoreChatModel(name) {
        // prefer model gede/baru: 70b/120b/llama-4 dulu, 8b kecil di belakang
        let s = 0;
        const p = name.match(/-(\d+)(?:\.(\d+))?b/);
        if (p) s += parseFloat(`${p[1]}.${p[2] || 0}`);
        if (/llama-4|maverick|scout/.test(name)) s += 20;
        if (/gpt-oss-120b|qwen|k2|deepseek/.test(name)) s += 10;
        if (/versatile|instruct|latest/.test(name)) s += 5;
        return s;
    }
    async function getProviderModels(name, catalogUrl, apiKey, fallbackModels) {
        if (providerModelCaches[name]) return providerModelCaches[name];
        let list = [];
        try {
            const res = await fetch(catalogUrl, { headers: { 'Authorization': 'Bearer ' + apiKey, 'Accept': 'application/json' } });
            if (res.ok) {
                const json = await res.json();
                const arr = Array.isArray(json) ? json : (json.data || json.models || []);
                list = arr.map(m => m.id || m.name).filter(n => n && !NON_CHAT_MODEL_RE.test(n))
                          .sort((a, b) => scoreChatModel(b) - scoreChatModel(a));
            } else log(`⚠️ ${name} katalog: HTTP ${res.status} — pakai daftar bawaan`);
        } catch (e) { log(`⚠️ ${name} katalog gagal:`, e); }
        const seen = new Set(); const out = [];
        [...list, ...fallbackModels].forEach(n => { if (!seen.has(n)) { seen.add(n); out.push(n); } });
        if (!out.length) return [];
        log(`🔹 ${name} kandidat model:`, out.slice(0, 5).join(', '), out.length > 5 ? `+${out.length - 5} lagi` : '');
        return (providerModelCaches[name] = out);
    }
    async function askOpenAICompat(name, endpoint, catalogUrl, fallbackModels, apiKey, content) {
        if (keyState.dead[name]) return { error: name + ' dimatikan hari ini (gagal berulang)' };
        if (!apiKey) return { error: name + ': key kosong' };
        if (state.aiCallCount >= CONFIG.MAX_AI_CALLS) return { error: 'Batas AI call' };
        const prompt = buildPrompt(content);
        const models = await getProviderModels(name, catalogUrl, apiKey, fallbackModels);
        if (!models.length) return { error: name + ': gagal tentukan model' };
        let lastErr = 'unknown';
        for (const model of models.slice(0, CONFIG.GEMINI_MAX_ATTEMPTS)) {
            state.aiCallCount++;
            try {
                log(`🔹 [${name}] coba ${model} [${state.aiCallCount}/${CONFIG.MAX_AI_CALLS}]`);
                const res = await fetch(endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
                    body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], temperature: 0.2, max_tokens: 1024 })
                });
                if (res.status === 429) { lastErr = `${model}: rate limit (429)`; log('⚠️', lastErr); continue; }
                if (!res.ok) { lastErr = `${model}: HTTP ${res.status}${res.status === 404 ? ' (model ketua — lewati)' : ''}`; log('❌', lastErr); continue; }
                const json = await res.json();
                const text = json?.choices?.[0]?.message?.content || '';
                if (!text.trim()) { lastErr = `${model}: kosong`; log('⚠️', lastErr); continue; }
                providerModelCaches[name] = [model];   // ✅ model terbukti jawab — pakai terus
                const parsed = parseAIResponse(text); if (parsed.error) return parsed;
                noteProvOk(name);
                log(`✅ ${name} jawab via ${model} (confidence ${parsed.confidence}%)`);
                return { ...parsed, model: name.toLowerCase() + ':' + model };
            } catch (e) { lastErr = `${model}: ${String(e).slice(0, 80)}`; log('❌', lastErr); }
        }
        noteProvFail(name);   // gagal total → hitung; 2x berturut-turut = auto-mati
        return { error: `${name} gagal — ${lastErr}` };
    }
    async function askAIGroq(content) {
        return askOpenAICompat('Groq', 'https://api.groq.com/openai/v1/chat/completions', 'https://api.groq.com/openai/v1/models', CONFIG.GROQ_MODELS, CONFIG.GROQ_API_KEY, content);
    }
    async function askAICerebras(content) {
        return askOpenAICompat('Cerebras', 'https://api.cerebras.ai/v1/chat/completions', 'https://api.cerebras.ai/v1/models', CONFIG.CEREBRAS_MODELS, CONFIG.CEREBRAS_API_KEY, content);
    }
    async function askAIGithub(content) {
        return askOpenAICompat('GitHub', 'https://models.github.ai/inference/chat/completions', 'https://models.github.ai/catalog/models', CONFIG.GITHUB_MODELS, CONFIG.GITHUB_TOKEN, content);
    }

    /* =========================================================================
       BACKEND 3: POLLINATIONS (pernah gratis, sekarang 402 paywall) — auto-skip
       ========================================================================= */
    async function askAIPollinations(content) {
        if (keyState.dead['Pollinations']) return { error: 'Pollinations dimatikan (paywall)' };
        const prompt = buildPrompt(content);
        const noImgNote = content.images.length > 0 ? '\n\n(Catatan: ada gambar di soal asli, tapi backend ini text-only — jawab dari teks yang ada.)' : '';
        let lastErr = 'unknown';
        for (const model of CONFIG.POLLI_MODELS) {
            try {
                log(`🟢 [Pollinations] coba ${model} (tanpa key)`);
                const res = await fetch('https://text.pollinations.ai/openai', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt + noImgNote }], temperature: 0.2, private: true })
                });
                if (res.status === 402 || res.status === 403) {
                    keyState.dead['Pollinations'] = true; saveKeyState();   // 👈 paywall — matikan buat sisa hari ini
                    log(`🚫 Pollinations kena paywall (HTTP ${res.status}) — dimatikan buat hari ini`);
                    return { error: `Pollinations paywall (HTTP ${res.status})` };
                }
                if (res.status === 429) { lastErr = `${model}: rate limit (tunggu ~30-60 dtk)`; log('⚠️ Pollinations', lastErr); continue; }
                if (!res.ok) { lastErr = `${model}: HTTP ${res.status}`; log('⚠️ Pollinations', lastErr); continue; }
                const json = await res.json();
                const text = json?.choices?.[0]?.message?.content || '';
                if (!text.trim()) { lastErr = `${model}: kosong`; log('⚠️ Pollinations', lastErr); continue; }
                const parsed = parseAIResponse(text); if (parsed.error) return parsed;
                return { ...parsed, model: 'pollinations:' + model };
            } catch (e) { lastErr = `${model}: ${String(e).slice(0, 80)}`; log('⚠️ Pollinations', lastErr); }
        }
        return { error: 'Pollinations gagal — ' + lastErr };
    }

    /* =========================================================================
       BACKEND 4: AI LOKAL CHROME (fallback gratis, tanpa key)
       ========================================================================= */
    function getLocalAIFactory() { if (!window.ai) return null; if (window.ai.languageModel) return window.ai.languageModel; if (window.ai.assistant) return window.ai.assistant; return null; }
    function localAIReady() { return !!getLocalAIFactory(); }
    async function askAILocal(content) {
        const factory = getLocalAIFactory(); if (!factory) return { error: 'window.ai tidak ada' };
        try {
            if (typeof factory.availability === 'function') { const avail = await factory.availability(); if (avail === 'unavailable') return { error: 'AI lokal unavailable' }; }
            if (!state.localSession) { try { state.localSession = await factory.create({ temperature: 0.2, topK: 1 }); } catch (e) { state.localSession = await factory.create(); } }
            const prompt = buildPrompt(content); const hasImages = content.images.length > 0; let text = '';
            if (hasImages && factory.supportsImageInput === true) { const img = await combineImagesToBase64(content.images); try { text = await state.localSession.prompt([{ type: 'text', value: prompt }, { type: 'image', value: img }]); } catch (e) { text = await state.localSession.prompt(prompt); } }
            else { if (hasImages) log('⚠️ AI lokal gak support gambar — teks saja'); text = await state.localSession.prompt(prompt); }
            if (!text || !String(text).trim()) return { error: 'empty' };
            const parsed = parseAIResponse(text); if (parsed.error) return parsed;
            return { ...parsed, model: 'local:gemma' };
        } catch (e) { return { error: 'local AI: ' + (e?.message || e) }; }
    }

    /* Dispatcher — MODE UTAMA 'groq':
       Groq (gpt-oss-120b, 1.000 req/hari) → kalau gagal/kuota abis → Gemini (rotasi key) → AI lokal.
       Provider lain tetep ada di mode 'auto'. Yang kedeteksi mati (dead) di-skip otomatis. */
    async function askAI(content) {
        const hasImg = content.images.length > 0;
        const mk = (label, fn, needKey) => async () => {
            if (keyState.dead[label]) return null;   // udah ditandai mati hari ini → skip total
            if (needKey && !needKey()) return null;
            const r = await fn(content);
            if (r && !r.error) return r;
            log('⚠️', label + ':', r?.error); return null;
        };
        const tryGemini = mk('Gemini', askAIGemini, () => geminiKeys().length > 0);
        const tryGroq = mk('Groq', askAIGroq, () => CONFIG.GROQ_API_KEY);
        const tryCerebras = mk('Cerebras', askAICerebras, () => CONFIG.CEREBRAS_API_KEY);
        const tryGithub = mk('GitHub', askAIGithub, () => CONFIG.GITHUB_TOKEN);
        const tryOpenRouter = mk('OpenRouter', askAIOpenRouter, () => CONFIG.OPENROUTER_API_KEY);
        const tryPolli = async () => {
            if (keyState.dead['Pollinations']) return null;
            const p = await askAIPollinations(content);
            if (p && !p.error) return p;
            log('⚠️ Pollinations:', p?.error); return null;
        };
        const tryLocal = async () => {
            if (!localAIReady()) return null;
            const l = await askAILocal(content);
            if (l && !l.error) return l;
            log('⚠️ Local:', l?.error); return null;
        };

        if (CONFIG.AI_BACKEND === 'groq') {
            // ⭐ MODE GROQ UTAMA — fallback cepat: Gemini → lokal (tanpa provider yang pernah macet)
            log('🟢 Route: Groq dulu (gpt-oss-120b, gratis)' + (hasImg ? ' — ⚠️ soal BERGAMBAR: Groq text-only, langsung Gemini vision' : ''));
            if (hasImg) {
                const gm = await tryGemini(); if (gm) return gm;
                const g = await tryGroq(); if (g) return g;
            } else {
                const g = await tryGroq(); if (g) return g;
                const gm = await tryGemini(); if (gm) return gm;
            }
            const l = await tryLocal(); if (l) return l;
            return { error: 'Groq & fallback gagal — cek msb.status()' };
        }
        if (CONFIG.AI_BACKEND === 'cerebras') return await askAICerebras(content);
        if (CONFIG.AI_BACKEND === 'github') return await askAIGithub(content);
        if (CONFIG.AI_BACKEND === 'pollinations') return await askAIPollinations(content);
        if (CONFIG.AI_BACKEND === 'openrouter') return await askAIOpenRouter(content);
        if (CONFIG.AI_BACKEND === 'local') { const l = await askAILocal(content); if (l && !l.error) return l; return l; }

        const { live } = liveGeminiKeys();
        log(hasImg ? `🖼️ Ada gambar → route: Gemini (vision, ${live.length} key hidup) → Groq → lokal`
                   : `📝 Teks → route: Gemini (${live.length} key hidup) → Groq → Cerebras → GitHub → Polli → lokal`);
        let r = null;
        if (CONFIG.AI_BACKEND === 'gemini') {
            // paksa Gemini dulu untuk SEMUA soal
            r = await tryGemini() || await tryGroq() || await tryCerebras() || await tryGithub() || await tryOpenRouter() || await tryPolli() || await tryLocal();
        } else if (hasImg) {
            r = await tryGemini() || await tryGroq() || await tryCerebras() || await tryGithub() || await tryOpenRouter() || await tryPolli() || await tryLocal();
        } else {
            r = await tryGemini() || await tryGroq() || await tryCerebras() || await tryGithub() || await tryOpenRouter() || await tryPolli() || await tryLocal();
        }
        return r || { error: 'Semua backend gagal' };
    }

    /* =========================================================================
       APPLY ANSWER
       ========================================================================= */
    function clickOption(o) {
        if (!o) return;
        if (o.input) { if (!o.input.checked) o.input.click(); o.input.checked = true; o.input.dispatchEvent(new Event('change', { bubbles: true })); o.input.dispatchEvent(new Event('input', { bubbles: true })); }
        if (o.el && o.el !== o.input) { o.el.click(); o.el.setAttribute('aria-selected', 'true'); o.el.setAttribute('aria-checked', 'true'); o.el.dispatchEvent(new MouseEvent('click', { bubbles: true })); }
    }
    function setNativeSelect(sel, targetText) {
        const cleanTarget = targetText.toLowerCase().trim().replace(/["'`\.]+$/g, ''); let bestOpt = null, bestScore = 0;
        Array.from(sel.options).forEach(opt => { const optText = opt.textContent.toLowerCase().trim(); if (isPlaceholderOption(optText)) return; let sc = 0; if (optText === cleanTarget) sc = 100; else if (optText.includes(cleanTarget) || cleanTarget.includes(optText)) sc = Math.min(optText.length, cleanTarget.length) / Math.max(optText.length, cleanTarget.length) * 100; if (sc > bestScore) { bestScore = sc; bestOpt = opt; } });
        if (bestOpt && bestScore >= 70) { sel.value = bestOpt.value; sel.dispatchEvent(new Event('change', { bubbles: true })); sel.dispatchEvent(new Event('input', { bubbles: true })); sel.dispatchEvent(new Event('blur', { bubbles: true })); return true; } return false;
    }
    function applyAnswer(root, answer, typeInfo) {
        if (!answer) return false; const clean = String(answer).trim(); const opts = typeInfo.options || [];
        try {
            if (typeInfo.type === 'checkbox' || typeInfo.multi) {
                const letters = clean.match(/[a-eA-E]/g) || []; const targets = letters.map(l => l.toLowerCase()); const cleanText = clean.toLowerCase(); let clicked = 0;
                opts.forEach(o => { const byLetter = targets.includes(o.letter.toLowerCase()); const ct = (o.text || '').toLowerCase(); const byText = ct && (cleanText.includes(ct) || ct.includes(cleanText.replace(/^[a-e][\.\)]\s*/i, ''))); if (byLetter || byText) { clickOption(o); clicked++; } });
                return clicked > 0;
            }
            if (typeInfo.type === 'select') return setNativeSelect(typeInfo.selectEl, clean);
            if (typeInfo.type === 'radio' || typeInfo.type === 'div' || typeInfo.type === 'unknown') {
                const letterMatch = clean.match(/^([a-eA-E])[\.\)\s]/); const targetLetter = letterMatch ? letterMatch[1].toLowerCase() : null; const cleanText = clean.toLowerCase().replace(/^[a-e][\.\)]\s*/i, '').trim();
                let best = null, bestScore = 0; opts.forEach(o => { let sc = 0; const ct = (o.text || '').toLowerCase().trim(); if (ct === cleanText) sc = 100; else if (ct.includes(cleanText) || cleanText.includes(ct)) sc = Math.min(ct.length, cleanText.length) / Math.max(ct.length, cleanText.length) * 100; if (targetLetter && o.letter.toLowerCase() === targetLetter) sc = Math.max(sc, 95); if (sc > bestScore) { bestScore = sc; best = o; } });
                if (best && bestScore >= CONFIG.MIN_APPLY_SCORE) { clickOption(best); return true; } return false;
            }
            if (typeInfo.type === 'text') { if (!typeInfo.inputEl) return false; typeInfo.inputEl.value = clean.replace(/^["'`]+|["'`]+$/g, '').trim(); typeInfo.inputEl.dispatchEvent(new Event('input', { bubbles: true })); typeInfo.inputEl.dispatchEvent(new Event('change', { bubbles: true })); return true; }
            if (typeInfo.type === 'textarea') { if (!typeInfo.inputEl) return false; typeInfo.inputEl.value = clean; typeInfo.inputEl.dispatchEvent(new Event('input', { bubbles: true })); typeInfo.inputEl.dispatchEvent(new Event('change', { bubbles: true })); return true; }
        } catch (e) { log('❌ Apply error:', e); }
        return false;
    }

    /* =========================================================================
       MARKS
       ========================================================================= */
    function addMark(root, type) { root.querySelectorAll('.msb-mark').forEach(m => m.remove()); const mark = document.createElement('span'); mark.className = `msb-mark ${type}`; mark.textContent = type === 'ok' ? '✓' : type === 'warn' ? '⚠' : type === 'img' ? '👁' : '✗'; const el = getQuestionTextEl(root); el.appendChild(mark); }
    function clearMarksOnly() { document.querySelectorAll('.msb-mark').forEach(m => m.remove()); }

    /* =========================================================================
       UI / WIDGET
       ========================================================================= */
    function build() {
        const root = document.body || document.documentElement; if (!root) return; if (document.getElementById('msb-container')) return;
        const container = document.createElement('div'); container.id = 'msb-container';
        const btnAnswer = document.createElement('button'); btnAnswer.id = 'msb-btn-answer'; btnAnswer.className = 'msb-btn'; btnAnswer.title = 'Jawab semua soal (Gemini)'; btnAnswer.innerHTML = `<span id="msb-badge" class="hidden">0</span>`;
        btnAnswer.addEventListener('click', async () => { if (container.dataset.dragged === '1') { container.dataset.dragged = '0'; return; } await runAll(); });
        const btnUndo = document.createElement('button'); btnUndo.id = 'msb-btn-undo'; btnUndo.className = 'msb-btn'; btnUndo.title = 'Hapus semua jawaban (undo)'; btnUndo.innerHTML = '↺';
        btnUndo.addEventListener('click', () => { if (container.dataset.dragged === '1') { container.dataset.dragged = '0'; return; } undoAll(); });
        container.addEventListener('contextmenu', (e) => { e.preventDefault(); e.stopPropagation(); });   // right-click di bola = jangan nembus ke anti-right-click site
        container.appendChild(btnAnswer); container.appendChild(btnUndo); root.appendChild(container); makeDraggable(container); restorePos(container); updateBadge();
    }
    let noQuizStreak = 0;
    function ensureWidget() {
        if (!document.body) return;
        // 🙈 mode disembunyikan (tombol C) → bola di-remove & GAK dibangun ulang
        if (ballHidden()) { const eb = document.getElementById('msb-container'); if (eb) eb.remove(); noQuizStreak = 0; return; }
        const qs = detectQuestions(); const hasQuiz = qs.length > 0 || location.search.includes('msb=on');
        if (!hasQuiz) {
            // 👇 JANGAN langsung hapus! Situs/ekstensi kadang nyembunyiin konten sesaat
            //    (right-click / tombol samping mouse / animasi) → deteksi kosong kilat-2an.
            //    Baru dihapus kalau 8 cek berurutan (±6 dtk) kosong DAN gak lagi di-window proteksi klik.
            if (++noQuizStreak >= 8 && Date.now() > protectUntil) { const eb = document.getElementById('msb-container'); if (eb) eb.remove(); }
            return;
        }
        noQuizStreak = 0;
        if (state.lastBody !== document.body) { state.lastBody = document.body; setTimeout(() => { injectStyles(); build(); attachBodyObserver(); }, 100); return; }
        if (!document.getElementById('msb-container')) { injectStyles(); build(); } if (!document.getElementById('msb-styles')) injectStyles();
    }
    function attachBodyObserver() { if (state.domObserver) state.domObserver.disconnect(); if (!document.body) return; state.domObserver = new MutationObserver((mutations) => { for (const m of mutations) { for (const node of m.removedNodes) { if (node.id === 'msb-container' || (node.querySelector && node.querySelector('#msb-container'))) { setTimeout(ensureWidget, 100); return; } } } }); state.domObserver.observe(document.body, { childList: true, subtree: true }); }
    function setupWatchdog() {
        if (state.watchdogTimer) clearInterval(state.watchdogTimer); state.watchdogTimer = setInterval(ensureWidget, 800);
        const rootObserver = new MutationObserver(() => { if (document.body && state.lastBody !== document.body) ensureWidget(); }); rootObserver.observe(document.documentElement, { childList: true, subtree: false }); attachBodyObserver();
        // 🖱️ klik spesial (capture-phase: tetap kedengar walau situs stopPropagation)
        //    → right-click (contextmenu) · middle (1) · tombol samping Back/Forward (3/4)
        const specialClick = (e) => { if (e.button === 1 || e.button === 3 || e.button === 4) protectBall(); };
        document.addEventListener('contextmenu', (e) => { protectBall(); }, true);
        document.addEventListener('mousedown', specialClick, true);
        document.addEventListener('mouseup', specialClick, true);
        document.addEventListener('auxclick', specialClick, true);
        window.addEventListener('pageshow', () => setTimeout(ensureWidget, 100));
        document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(ensureWidget, 100); });
        window.addEventListener('hashchange', () => setTimeout(ensureWidget, 100));
        window.addEventListener('popstate', () => { protectBall(); setTimeout(ensureWidget, 100); });   // Back/Forward via keyboard/spa juga diproteksi
        window.addEventListener('keydown', (e) => {
            if (e.altKey && (e.key === 'm' || e.key === 'M')) { e.preventDefault(); toggleBall(); return; }
            // Tombol C doang = toggle bola (di luar input) + proteksi bola 4 dtk.
            // Ctrl/Cmd+C (copy) & ngetik 'c' di jawaban TIDAK ke-trigger.
            if ((e.key === 'c' || e.key === 'C') && !e.ctrlKey && !e.metaKey && !e.altKey) {
                protectBall();
                const t = e.target;
                const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
                if (!typing) toggleBall();
            }
        });
    }
    function updateBadge() { const bd = document.getElementById('msb-badge'); if (!bd) return; const n = Object.keys(state.database).length; if (n > 0) { bd.classList.remove('hidden'); bd.textContent = n > 99 ? '99+' : n; } else bd.classList.add('hidden'); }
    function makeDraggable(el) { let dragging = false, moved = false, sx, sy, ox, oy; el.addEventListener('mousedown', (e) => { dragging = true; moved = false; sx = e.clientX; sy = e.clientY; const r = el.getBoundingClientRect(); ox = r.left; oy = r.top; }); document.addEventListener('mousemove', (e) => { if (!dragging) return; const dx = e.clientX - sx, dy = e.clientY - sy; if (Math.abs(dx) > 3 || Math.abs(dy) > 3) moved = true; el.style.left = (ox + dx) + 'px'; el.style.top = (oy + dy) + 'px'; el.style.right = 'auto'; el.style.bottom = 'auto'; }); document.addEventListener('mouseup', () => { if (!dragging) return; dragging = false; if (moved) { el.dataset.dragged = '1'; const r = el.getBoundingClientRect(); localStorage.setItem(CONFIG.POS_KEY, JSON.stringify({ left: r.left, top: r.top })); } }); }
    function restorePos(el) { try { const s = JSON.parse(localStorage.getItem(CONFIG.POS_KEY) || 'null'); if (s) { el.style.right = 'auto'; el.style.bottom = 'auto'; el.style.left = s.left + 'px'; el.style.top = s.top + 'px'; } } catch (e) {} }

    /* Toggle bola via tombol C / Alt+M: sembunyi ↔ muncul (state ke-save) */
    function ballHidden() { try { return localStorage.getItem('msb_ball_hidden') === '1'; } catch (e) { return false; } }
    function toggleBall() {
        const nowHidden = !ballHidden();   // kalau lagi kelihatan → sembunyikan
        try { localStorage.setItem('msb_ball_hidden', nowHidden ? '1' : '0'); } catch (e) {}
        log(nowHidden ? '🙈 Bola DISEMBUNYIKAN (tekan C lagi buat munculin)' : '👁️ Bola MUNCUL lagi');
        toast(nowHidden ? '🙈 Bola disembunyikan — C buat munculin lagi' : '👁️ Bola muncul', 2000);
        noQuizStreak = 0; setTimeout(ensureWidget, 50);
    }

    /* PROTEKSI KLIK SPESIAL: right-click / middle-click / tombol samping mouse (3/4)
       → situs anti-copy biasanya nyembunyiin konten sesaat → bola jangan disentuh! */
    let protectUntil = 0;
    function protectBall(ms = 4000) { protectUntil = Date.now() + ms; noQuizStreak = 0; }

    /* =========================================================================
       RUN
       ========================================================================= */
    async function runAll() {
        if (state.busy) { toast('Proses...', 1000); return; }
        const qs = detectQuestions(); if (!qs.length) { toast('Tidak ada soal terdeteksi', 1500); return; }
        if (!geminiKeys().length && !CONFIG.OPENROUTER_API_KEY && !localAIReady()) toast('Gak ada key Gemini → msb.addGeminiKey("key") atau isi GEMINI_API_KEYS di CONFIG', 5000);
        state.busy = true; state.aiCallCount = 0;
        log('=== MULAI ===  Total soal:', qs.length, '| backend:', CONFIG.AI_BACKEND, '| gemini keys:', geminiKeys().length, `(hidup: ${liveGeminiKeys().live.length})`, '| openrouter:', CONFIG.OPENROUTER_API_KEY ? 'ada' : 'kosong', '| local:', localAIReady());
        if (CONFIG.GEMINI_API_KEY) await getGeminiModelCandidates();
        state.database = await readDB(state.blobId);
        let ok = 0, fail = 0, warn = 0, imgOK = 0; const newAI = {};
        for (let i = 0; i < qs.length; i++) {
            const root = qs[i]; const content = extractQuestionContent(root); const hash = content.text ? hashQ(content.text) : null; const hasImg = content.images.length > 0;
            log(`[${i + 1}/${qs.length}] Tipe: ${content.typeInfo.type} | Options: ${content.options.length} | Imgs: ${content.images.length}`);
            if (content.typeInfo.type === 'unknown') { addMark(root, 'fail'); fail++; continue; }
            if (hash && state.database[hash]) { const d = state.database[hash]; if (applyAnswer(root, d.answer, content.typeInfo)) { addMark(root, 'ok'); ok++; } else { addMark(root, 'fail'); fail++; } continue; }
            const result = await askAI(content);
            if (result && result.answer) {
                const conf = result.confidence || 50; const lowConf = conf < CONFIG.MIN_AI_CONFIDENCE;
                if (applyAnswer(root, result.answer, content.typeInfo)) { if (lowConf) { addMark(root, 'warn'); warn++; } else { addMark(root, hasImg ? 'img' : 'ok'); if (hasImg) imgOK++; else ok++; } }
                else { addMark(root, 'fail'); fail++; }
                if (CONFIG.AUTO_SAVE_AI && hash && !lowConf) { newAI[hash] = { answer: result.answer, votes: 1, source: result.model || 'gemini', confidence: conf, type: content.typeInfo.type, model: result.model, text: content.text.substring(0, 200), updatedAt: Date.now() }; }
            } else { addMark(root, 'fail'); fail++; }
        }
        if (Object.keys(newAI).length > 0) { const merged = { ...state.database, ...newAI }; if (await writeDB(state.blobId, merged)) state.database = merged; }
        state.busy = false; updateBadge(); log('=== SELESAI ===');
        let msg = `✓ ${ok}`; if (imgOK > 0) msg += ` · 👁 ${imgOK}`; if (warn > 0) msg += ` · ⚠ ${warn}`; if (fail > 0) msg += ` · ✗ ${fail}`;
        toast(msg, 3500);
    }

    /* =========================================================================
       INIT
       ========================================================================= */
    async function init() {
        await waitForDOM(); injectStyles(); build(); state.lastBody = document.body;
        keyState = loadKeyState(); saveKeyState();
        state.blobId = localStorage.getItem(CONFIG.STORAGE_KEY); if (!state.blobId) { const id = await newBlob(); if (id) { state.blobId = id; localStorage.setItem(CONFIG.STORAGE_KEY, id); } }
        state.database = await readDB(state.blobId); updateBadge(); setupWatchdog();
        const { keys, live } = liveGeminiKeys();
        if (!keys.length && !localAIReady()) log('⚠️ Isi GEMINI_API_KEYS di CONFIG (atau enable AI lokal Chrome)');
        else log('✅ Backend siap — Gemini keys:', keys.length, `(hidup: ${live.length}, exhausted: ${Object.keys(keyState.exhausted).length}, dead: ${Object.keys(keyState.dead).length})`, '| local:', localAIReady());
    }

    // Public API:
    //   msb.run() / msb.undo() / msb.clearMarks()
    //   msb.addGeminiKey('key') ← tambah key (kuota nambah) / msb.status() / msb.resetQuota()
    //   msb.useGemini() / msb.useAuto() / msb.useGroq('key') / msb.useCerebras('key') / msb.useGithub('token')
    //   msb.useOpenRouter('key') / msb.usePollinations() / msb.useLocal() / msb.models()
    //   msb.testGemini() / msb.testGroq() / msb.testCerebras() / msb.testGithub() / msb.testPollinations() / msb.testLocal()
    window.msb = {
        run: runAll, undo: undoAll, clearMarks: clearMarksOnly, toggle: toggleBall,
        addGeminiKey: (k) => {
            if (!k) return console.log('❌ kasih key-nya: msb.addGeminiKey("AQ.Ab8...")');
            CONFIG.GEMINI_API_KEYS.push(k);
            const idx = geminiKeys().indexOf(k);
            delete keyState.exhausted[idx]; delete keyState.dead[idx]; saveKeyState();
            log('🔑 Gemini key #' + (idx + 1) + ' ditambah (' + maskKey(k) + ') — kuota nambah ~500 req/hari');
            toast('✅ Key #' + (idx + 1) + ' ditambah — total ' + geminiKeys().length + ' key', 2500);
            return 'total key: ' + geminiKeys().length;
        },
        status: () => {
            const { keys, live } = liveGeminiKeys();
            console.log('📊 === STATUS MSB v2.0 (unlimited) ===');
            console.log('🔐 Gemini keys:', keys.length, '| hidup:', live.length);
            keys.forEach((k, i) => console.log(`   key#${i + 1} ${maskKey(k)} → ${keyState.dead[i] ? '🔴 DEAD (invalid)' : keyState.exhausted[i] ? '🟡 EXHAUSTED (429)' : '🟢 OK'}`));
            console.log('🚫 Provider mati hari ini:', Object.keys(keyState.dead).filter(n => isNaN(n)).join(', ') || 'tidak ada');
            console.log('📌 Model Gemini aktif:', geminiModelCache || 'belum ada');
            console.log('🧠 AI calls sesi ini:', state.aiCallCount, '| backend:', CONFIG.AI_BACKEND);
            console.log('💾 Jawaban ter-cache (blob):', Object.keys(state.database).length);
            return keyState;
        },
        resetQuota: () => {
            keyState = freshKeyState(); saveKeyState(); geminiModelCache = null;
            Object.keys(provFailCount).forEach(k => delete provFailCount[k]);
            log('🔄 Semua penanda exhausted/dead direset — semua key & provider aktif lagi');
            toast('🔄 Kuota & provider direset', 2000);
        },
        setGeminiKey: (key) => { if (key) { CONFIG.GEMINI_API_KEYS = [key]; CONFIG.GEMINI_API_KEY = ''; keyState = freshKeyState(); saveKeyState(); } geminiModelCache = null; log('🔑 Gemini key diset (daftar di-reset ke 1 key)'); toast('Gemini key diset', 1500); },
        useGemini: (key) => { if (key) { CONFIG.GEMINI_API_KEY = key; geminiModelCache = null; } CONFIG.AI_BACKEND = 'gemini'; log('🔁 -> gemini dulu untuk SEMUA soal'); toast('Backend: Gemini (semua soal)', 2000); },
        useAuto: () => { CONFIG.AI_BACKEND = 'auto'; log('🔁 -> auto UNLIMITED (Gemini rotasi key → Groq → Cerebras → GitHub → Polli → lokal)'); toast('Backend: Auto (unlimited)', 2000); },
        useGroqFirst: () => { CONFIG.AI_BACKEND = 'groq'; log('🔁 -> GROQ UTAMA (gpt-oss-120b, fallback Gemini)'); toast('Backend: Groq utama', 2000); },
        useOpenRouter: (key) => { if (key) { CONFIG.OPENROUTER_API_KEY = key; openRouterModelsCache = null; } CONFIG.AI_BACKEND = 'openrouter'; log('🔁 -> openrouter'); toast('Backend: OpenRouter (:free)', 2000); },
        usePollinations: () => { CONFIG.AI_BACKEND = 'pollinations'; log('🔁 -> pollinations (kemungkinan 402 paywall)'); toast('Backend: Pollinations', 2000); },
        useGroq: (key) => { if (key) { CONFIG.GROQ_API_KEY = key; } CONFIG.AI_BACKEND = 'groq'; log('🔁 -> groq (14k req/hari, gratis)'); toast('Backend: Groq', 2000); },
        useCerebras: (key) => { if (key) { CONFIG.CEREBRAS_API_KEY = key; } CONFIG.AI_BACKEND = 'cerebras'; log('🔁 -> cerebras'); toast('Backend: Cerebras', 2000); },
        useGithub: (token) => { if (token) { CONFIG.GITHUB_TOKEN = token; } CONFIG.AI_BACKEND = 'github'; log('🔁 -> github models'); toast('Backend: GitHub Models', 2000); },
        useLocal: () => { CONFIG.AI_BACKEND = 'local'; state.localSession = null; log('🔁 -> local'); toast('Backend: AI lokal', 2000); },
        models: async () => {
            const cands = await getGeminiModelCandidates();
            console.log('🤖 Kandidat Gemini (urut prioritas):', cands);
            console.log('📌 Cached (model terbukti jalan):', geminiModelCache || 'belum ada');
            return cands;
        },
        testGemini: async () => {
            if (!CONFIG.GEMINI_API_KEY) return console.log('❌ Isi Gemini key dulu');
            const cands = await getGeminiModelCandidates();
            if (!cands.length) return console.log('❌ Gagal tentukan model');
            for (const m of cands.slice(0, CONFIG.GEMINI_MAX_ATTEMPTS)) {
                try {
                    const url = `https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${encodeURIComponent(CONFIG.GEMINI_API_KEY)}`;
                    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: 'Jawab singkat: ibu kota Indonesia?' }] }] }) });
                    if (!res.ok) { console.log(`❌ ${m}: HTTP ${res.status}`); continue; }
                    const j = await res.json();
                    const text = (j?.candidates?.[0]?.content?.parts || []).filter(p => p.text && !p.thought).map(p => p.text).join('');
                    if (!text.trim()) { console.log(`⚠️ ${m}: kosong (${j?.candidates?.[0]?.finishReason || j?.promptFeedback?.blockReason || '?'})`); continue; }
                    geminiModelCache = m;
                    console.log('✅ Gemini (' + m + ') ->', text.trim());
                    return;
                } catch (e) { console.log('❌ ' + m + ':', e); }
            }
            console.log('❌ Semua kandidat model gagal');
        },
        testLocal: async () => { if (!localAIReady()) return console.log('❌ window.ai gak ada'); try { const s = await getLocalAIFactory().create({ temperature: 0.2 }); console.log('✅ Local (Gemma 4) ->', await s.prompt('Ibu kota Indonesia?')); } catch (e) { console.log('❌ Local error:', e); } },
        testPollinations: async () => {
            try {
                const res = await fetch('https://text.pollinations.ai/openai', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: CONFIG.POLLI_MODELS[0], messages: [{ role: 'user', content: 'Jawab singkat: ibu kota Indonesia?' }], temperature: 0.2, private: true }) });
                if (res.status === 402 || res.status === 403) return console.log('🚫 Pollinations kena paywall (HTTP ' + res.status + ') — pakai Groq/Cerebras/GitHub aja');
                if (!res.ok) return console.log('❌ Pollinations: HTTP', res.status);
                const j = await res.json();
                console.log('✅ Pollinations (' + CONFIG.POLLI_MODELS[0] + ') ->', j?.choices?.[0]?.message?.content || JSON.stringify(j).slice(0, 100));
            } catch (e) { console.log('❌', e); }
        },
        testGroq: async () => {
            if (!CONFIG.GROQ_API_KEY) return console.log('❌ Isi GROQ_API_KEY dulu (GRATIS: https://console.groq.com/keys)');
            await askAIGroq({ text: 'Jawab singkat: ibu kota Indonesia?', images: [], typeInfo: { type: 'text', options: [] }, options: [] });
            console.log('(cek log di atas — sukses = jawaban Jakarta)');
        },
        testCerebras: async () => {
            if (!CONFIG.CEREBRAS_API_KEY) return console.log('❌ Isi CEREBRAS_API_KEY dulu (GRATIS: https://cloud.cerebras.ai)');
            await askAICerebras({ text: 'Jawab singkat: ibu kota Indonesia?', images: [], typeInfo: { type: 'text', options: [] }, options: [] });
            console.log('(cek log di atas — sukses = jawaban Jakarta)');
        },
        testGithub: async () => {
            if (!CONFIG.GITHUB_TOKEN) return console.log('❌ Isi GITHUB_TOKEN dulu (GRATIS: buat PAT di https://github.com/settings/tokens, tanpa scope)');
            await askAIGithub({ text: 'Jawab singkat: ibu kota Indonesia?', images: [], typeInfo: { type: 'text', options: [] }, options: [] });
            console.log('(cek log di atas — sukses = jawaban Jakarta)');
        },
        testOpenRouter: async () => {
            if (!CONFIG.OPENROUTER_API_KEY) return console.log('❌ Isi OPENROUTER_API_KEY dulu (gratis: https://openrouter.ai/keys)');
            const models = await getOpenRouterFreeModels();
            console.log('🟣 Model :free tersedia:', models.length);
            for (const m of models.slice(0, CONFIG.GEMINI_MAX_ATTEMPTS)) {
                try {
                    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + CONFIG.OPENROUTER_API_KEY }, body: JSON.stringify({ model: m, messages: [{ role: 'user', content: 'Jawab singkat: ibu kota Indonesia?' }], temperature: 0.2, max_tokens: 256 }) });
                    if (!res.ok) { console.log(`❌ ${m}: HTTP ${res.status}`); continue; }
                    const j = await res.json();
                    const text = j?.choices?.[0]?.message?.content || '';
                    if (!text.trim()) { console.log(`⚠️ ${m}: kosong`); continue; }
                    openRouterModelsCache = [m];
                    console.log('✅ OpenRouter (' + m + ') ->', text.trim());
                    return;
                } catch (e) { console.log('❌ ' + m + ':', e); }
            }
            console.log('❌ Semua model :free gagal');
        },
        copyRoom: () => { navigator.clipboard.writeText(state.blobId); toast('Room ID dicopy!', 1500); },
        rebuild: () => { state.lastBody = null; ensureWidget(); },
        inspect: () => { const qs = detectQuestions(); console.log('=== INSPECT ===  Soal:', qs.length, '| backend:', CONFIG.AI_BACKEND, '| key:', CONFIG.GEMINI_API_KEY ? 'ada' : 'kosong', '| local:', localAIReady()); if (!qs.length) return 'no questions'; const c = extractQuestionContent(qs[0]); console.log('Tipe:', c.typeInfo.type, '| Options:', c.options.length, '| Images:', c.images.length); console.log('Teks:', c.text.substring(0, 200)); return c; }
    };

    /* Sinkron key dari extension popup (chrome.storage → bridge.js → postMessage).
       Di userscript ini jadi no-op (gak ada yang ngirim pesan ini). */
    window.addEventListener('message', (e) => {
        const d = e && e.data;
        if (!d || d.type !== 'msb_keys' || e.source !== window) return;
        try {
            if (typeof d.groq === 'string' && d.groq && d.groq !== CONFIG.GROQ_API_KEY) { CONFIG.GROQ_API_KEY = d.groq; providerModelCaches['Groq'] = null; log('🔑 Groq key diterima dari popup'); }
            if (Array.isArray(d.gemini)) {
                const incoming = d.gemini.filter(Boolean);
                if (incoming.length && JSON.stringify(incoming) !== JSON.stringify(geminiKeys())) { CONFIG.GEMINI_API_KEYS = incoming; keyState = freshKeyState(); saveKeyState(); geminiModelCache = null; log('🔑', incoming.length, 'Gemini key diterima dari popup'); }
            }
        } catch (err) {}
    });

    init();

})();
