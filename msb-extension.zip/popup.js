/* Popup MSB Quiz Helper — manajemen key (chrome.storage) + kontrol halaman. */
function show(msg) {
    const el = document.getElementById('msg') || (() => { const d = document.createElement('div'); d.id = 'msg'; document.body.appendChild(d); return d; })();
    el.textContent = typeof msg === 'string' ? msg : JSON.stringify(msg);
}

/* ---------- KEY MANAGEMENT ---------- */
const groqInput = document.getElementById('k-groq');
const geminiInput = document.getElementById('k-gemini');
const statusEl = document.getElementById('key-status');

function refreshStatus() {
    chrome.storage.local.get(['groq_key', 'gemini_keys'], (d) => {
        groqInput.value = d.groq_key || '';
        geminiInput.value = (d.gemini_keys || []).join('\n');
        const ok = !!(d.groq_key || (d.gemini_keys || []).length);
        statusEl.textContent = ok
            ? '✅ Key tersimpan — berlaku di semua situs (halaman lama: refresh sekali)'
            : '⚠️ Belum ada key — isi Groq key dulu (gratis: console.groq.com/keys)';
        statusEl.style.color = ok ? '#9fdca4' : '#ffcc55';
    });
}

document.getElementById('k-save').addEventListener('click', () => {
    const gemini = geminiInput.value.split('\n').map(s => s.trim()).filter(Boolean);
    chrome.storage.local.set({ groq_key: groqInput.value.trim(), gemini_keys: gemini }, () => {
        refreshStatus();
        show('🔑 Key disimpan — refresh halaman soal kalau lagi kebuka');
    });
});

refreshStatus();

/* ---------- KONTROL HALAMAN ---------- */
async function callMSB(fnName) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return;
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: 'MAIN',   // penting: window.msb hidup di MAIN world (page context)
            func: (name) => {
                if (!window.msb) return { error: 'Bola gak ada di halaman ini — buka halaman soal dulu' };
                try {
                    const out = window.msb[name] && window.msb[name]();
                    if (name === 'inspect') return out && typeof out === 'object'
                        ? { type: out.typeInfo?.type, options: out.options?.length, images: out.images?.length, text: (out.text || '').slice(0, 120) }
                        : out;
                    return { ok: name };
                } catch (e) { return { error: String(e) }; }
            },
            args: [fnName]
        });
        const r = results?.[0]?.result;
        if (r && r.error) show(r.error);
        else if (r && r.type) show(`Tipe: ${r.type} · opsi: ${r.options} · img: ${r.images}`);
        else if (fnName === 'inspect') show('Tidak ada soal terdeteksi di halaman ini');
        else show({ run: '▶ Menjawab semua soal...', undo: '↺ Jawaban dihapus', toggle: '👁 Bola di-toggle' }[fnName] || 'OK');
    } catch (e) {
        show('Gagal: ' + (e?.message || e) + ' (halaman sistem chrome:// gak bisa diinject)');
    }
}

document.getElementById('b-run').addEventListener('click', () => { callMSB('run'); window.close(); });
document.getElementById('b-undo').addEventListener('click', () => { callMSB('undo'); window.close(); });
document.getElementById('b-toggle').addEventListener('click', () => { callMSB('toggle'); window.close(); });
document.getElementById('b-insp').addEventListener('click', () => callMSB('inspect'));
