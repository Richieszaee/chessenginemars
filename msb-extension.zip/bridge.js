/* bridge.js — ISOLATED world.
   Jembatan chrome.storage.local (key API dari popup) → halaman (MAIN world)
   via postMessage. Di-send saat load + tiap ada perubahan storage. */
function sendKeys() {
    try {
        chrome.storage.local.get(['groq_key', 'gemini_keys'], (d) => {
            window.postMessage({
                type: 'msb_keys',
                groq: d.groq_key || '',
                gemini: d.gemini_keys || []
            }, '*');
        });
    } catch (e) { /* storage gak tersedia (mis. halaman khusus) */ }
}

try {
    chrome.storage.onChanged.addListener((_c, area) => { if (area === 'local') sendKeys(); });
} catch (e) {}

sendKeys();
